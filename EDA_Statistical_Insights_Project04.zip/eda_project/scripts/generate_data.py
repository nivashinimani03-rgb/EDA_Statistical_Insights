"""
generate_data.py
Generates a realistic synthetic retail/business transactions dataset
(10,000+ rows) for exploratory data analysis.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 12000

regions = ["North", "South", "East", "West", "Central"]
region_weights = [0.24, 0.22, 0.19, 0.20, 0.15]

categories = ["Electronics", "Apparel", "Home & Kitchen", "Grocery", "Beauty", "Sports"]
category_weights = [0.22, 0.20, 0.18, 0.16, 0.14, 0.10]

segments = ["New", "Regular", "Loyal", "VIP"]
segment_weights = [0.30, 0.35, 0.24, 0.11]

channels = ["Online", "In-Store", "Marketplace"]
channel_weights = [0.52, 0.31, 0.17]

payment_methods = ["Credit Card", "UPI", "Debit Card", "Net Banking", "Cash on Delivery"]
payment_weights = [0.34, 0.30, 0.16, 0.11, 0.09]

# base price per category (mean, std) to keep prices realistic
category_price_params = {
    "Electronics": (5200, 2600),
    "Apparel": (950, 420),
    "Home & Kitchen": (1800, 800),
    "Grocery": (320, 140),
    "Beauty": (650, 260),
    "Sports": (1400, 600),
}

dates = pd.date_range("2024-01-01", "2025-12-31", freq="D")

rows = []
for i in range(N):
    region = np.random.choice(regions, p=region_weights)
    category = np.random.choice(categories, p=category_weights)
    segment = np.random.choice(segments, p=segment_weights)
    channel = np.random.choice(channels, p=channel_weights)
    payment = np.random.choice(payment_methods, p=payment_weights)
    order_date = np.random.choice(dates)

    mean_p, std_p = category_price_params[category]
    unit_price = max(50, np.random.normal(mean_p, std_p))
    quantity = np.random.choice([1, 1, 1, 2, 2, 3, 4, 5], p=[0.32, 0.18, 0.12, 0.14, 0.09, 0.08, 0.04, 0.03])

    # segment influences discount behavior (loyal/VIP get slightly higher avg discount via promos)
    segment_discount_bias = {"New": 0.02, "Regular": 0.04, "Loyal": 0.07, "VIP": 0.10}
    discount = np.clip(np.random.beta(2, 8) + segment_discount_bias[segment], 0, 0.6)

    gross_revenue = unit_price * quantity
    revenue = gross_revenue * (1 - discount)

    # cost as a category-based margin ratio with noise
    base_margin = {
        "Electronics": 0.18, "Apparel": 0.35, "Home & Kitchen": 0.28,
        "Grocery": 0.12, "Beauty": 0.40, "Sports": 0.25,
    }[category]
    margin_noise = np.random.normal(0, 0.05)
    profit_margin = np.clip(base_margin + margin_noise - discount * 0.3, -0.15, 0.6)
    profit = revenue * profit_margin

    # retention flag: higher discount & loyal/VIP segment increase repeat-purchase likelihood
    retention_score = (
        0.15
        + 0.35 * discount
        + {"New": 0.0, "Regular": 0.08, "Loyal": 0.22, "VIP": 0.32}[segment]
        + np.random.normal(0, 0.12)
    )
    retained_next_quarter = np.random.rand() < np.clip(retention_score, 0.02, 0.95)

    delivery_days = max(1, int(np.random.normal(4.5, 2.0))) if channel != "In-Store" else 0

    satisfaction = np.clip(
        np.random.normal(
            4.1 + (0.4 if segment in ["Loyal", "VIP"] else 0) - (delivery_days * 0.03), 0.7
        ),
        1, 5,
    )

    customer_age = int(np.clip(np.random.normal(34, 11), 18, 75))

    rows.append({
        "OrderID": f"ORD{100000+i}",
        "OrderDate": pd.Timestamp(order_date),
        "Region": region,
        "Category": category,
        "CustomerSegment": segment,
        "SalesChannel": channel,
        "PaymentMethod": payment,
        "CustomerAge": customer_age,
        "UnitPrice": round(unit_price, 2),
        "Quantity": int(quantity),
        "DiscountRate": round(discount, 4),
        "GrossRevenue": round(gross_revenue, 2),
        "Revenue": round(revenue, 2),
        "ProfitMargin": round(profit_margin, 4),
        "Profit": round(profit, 2),
        "DeliveryDays": delivery_days,
        "CustomerSatisfaction": round(satisfaction, 2),
        "RetainedNextQuarter": bool(retained_next_quarter),
    })

df = pd.DataFrame(rows)

# introduce a small amount of realistic noise (a few missing satisfaction scores)
missing_idx = np.random.choice(df.index, size=60, replace=False)
df.loc[missing_idx, "CustomerSatisfaction"] = np.nan

df.to_csv("/home/claude/eda_project/data/business_transactions.csv", index=False)
print(f"Generated {len(df)} rows -> data/business_transactions.csv")
print(df.dtypes)
