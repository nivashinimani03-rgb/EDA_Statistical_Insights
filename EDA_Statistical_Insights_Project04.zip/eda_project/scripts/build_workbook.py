"""
build_workbook.py
Builds the Excel deliverable: EDA_Statistical_Insights.xlsx
  - Raw Data          : full transaction dataset
  - Summary Stats      : formula-driven descriptive statistics
  - Hypothesis Tests    : formula-driven t-test / ANOVA / correlation
  - KPI Dashboard       : formula-driven KPI + region/category rollups
All numbers are computed via live Excel formulas referencing Raw Data,
not hardcoded Python results.
"""

from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "business_transactions.csv"
OUT = ROOT / "reports" / "EDA_Statistical_Insights.xlsx"

df = pd.read_csv(DATA, parse_dates=["OrderDate"])
n = len(df)

FONT = "Arial"
HEADER_FILL = PatternFill("solid", fgColor="1F2937")
HEADER_FONT = Font(name=FONT, bold=True, color="FFFFFF", size=11)
TITLE_FONT = Font(name=FONT, bold=True, size=15, color="1F2937")
SUBTITLE_FONT = Font(name=FONT, italic=True, size=10, color="6B7280")
LABEL_FONT = Font(name=FONT, bold=True, size=10)
NORMAL = Font(name=FONT, size=10)
THIN = Side(style="thin", color="D1D5DB")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
ACCENT_FILL = PatternFill("solid", fgColor="EEF2FF")

wb = Workbook()

# ================================================================= Raw Data
ws = wb.active
ws.title = "Raw Data"
cols = list(df.columns)
for j, c in enumerate(cols, 1):
    cell = ws.cell(row=1, column=j, value=c)
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="center")

for i, row in enumerate(df.itertuples(index=False), start=2):
    for j, val in enumerate(row, 1):
        v = val
        if cols[j - 1] == "OrderDate":
            v = val.strftime("%Y-%m-%d") if hasattr(val, "strftime") else val
        ws.cell(row=i, column=j, value=v).font = NORMAL

for j, c in enumerate(cols, 1):
    width = max(12, min(22, len(c) + 4))
    ws.column_dimensions[get_column_letter(j)].width = width
ws.freeze_panes = "A2"
last_row = n + 1
col_letter = {c: get_column_letter(i + 1) for i, c in enumerate(cols)}

# ================================================================= Summary Stats
ws2 = wb.create_sheet("Summary Stats")
ws2["A1"] = "Summary Descriptive Statistics"
ws2["A1"].font = TITLE_FONT
ws2["A2"] = "Mean, median, standard deviation, and quartiles — computed live from Raw Data"
ws2["A2"].font = SUBTITLE_FONT

numeric_cols = ["CustomerAge", "UnitPrice", "Quantity", "DiscountRate", "GrossRevenue",
                "Revenue", "ProfitMargin", "Profit", "DeliveryDays", "CustomerSatisfaction"]

headers = ["Metric", "Count", "Mean", "Median", "Std Dev", "Min", "Q1 (25%)", "Q3 (75%)", "Max", "Missing"]
hr = 4
for j, h in enumerate(headers, 1):
    c = ws2.cell(row=hr, column=j, value=h)
    c.font = HEADER_FONT
    c.fill = HEADER_FILL
    c.alignment = Alignment(horizontal="center")

for i, metric in enumerate(numeric_cols, start=hr + 1):
    rng = f"'Raw Data'!{col_letter[metric]}2:{col_letter[metric]}{last_row}"
    ws2.cell(row=i, column=1, value=metric).font = LABEL_FONT
    ws2.cell(row=i, column=2, value=f"=COUNT({rng})")
    ws2.cell(row=i, column=3, value=f"=AVERAGE({rng})")
    ws2.cell(row=i, column=4, value=f"=MEDIAN({rng})")
    ws2.cell(row=i, column=5, value=f"=STDEV({rng})")
    ws2.cell(row=i, column=6, value=f"=MIN({rng})")
    ws2.cell(row=i, column=7, value=f"=QUARTILE({rng},1)")
    ws2.cell(row=i, column=8, value=f"=QUARTILE({rng},3)")
    ws2.cell(row=i, column=9, value=f"=MAX({rng})")
    ws2.cell(row=i, column=10, value=f"=COUNTBLANK({rng})")
    for j in range(2, 11):
        cell = ws2.cell(row=i, column=j)
        cell.font = NORMAL
        cell.number_format = "0.00" if metric != "DiscountRate" and metric != "ProfitMargin" else "0.00%"
        cell.border = BORDER

for col, w in zip("ABCDEFGHIJ", [22, 9, 12, 12, 12, 12, 12, 12, 12, 10]):
    ws2.column_dimensions[col].width = w

# ================================================================= Hypothesis Tests
ws3 = wb.create_sheet("Hypothesis Tests")
ws3["A1"] = "Hypothesis Testing (α = 0.05)"
ws3["A1"].font = TITLE_FONT
ws3["A2"] = "Live formulas referencing Raw Data — recalculates automatically if data changes"
ws3["A2"].font = SUBTITLE_FONT

retdisc = col_letter["DiscountRate"]
retflag = col_letter["RetainedNextQuarter"]
region_c = col_letter["Region"]
revenue_c = col_letter["Revenue"]
margin_c = col_letter["ProfitMargin"]
disc_c = col_letter["DiscountRate"]

# Helper columns (non-array) so T.TEST doesn't rely on CSE array entry:
# Placed in Raw Data sheet, columns beyond the data table.
helper_retained_col = get_column_letter(len(cols) + 2)   # e.g. discount if retained
helper_not_retained_col = get_column_letter(len(cols) + 3)
ws.cell(row=1, column=len(cols) + 2, value="DiscountIfRetained").font = HEADER_FONT
ws.cell(row=1, column=len(cols) + 2).fill = HEADER_FILL
ws.cell(row=1, column=len(cols) + 3, value="DiscountIfNotRetained").font = HEADER_FONT
ws.cell(row=1, column=len(cols) + 3).fill = HEADER_FILL
for i in range(2, last_row + 1):
    ws.cell(row=i, column=len(cols) + 2,
             value=f'=IF({retflag}{i}=TRUE,{retdisc}{i},"")')
    ws.cell(row=i, column=len(cols) + 3,
             value=f'=IF({retflag}{i}=FALSE,{retdisc}{i},"")')
ws.column_dimensions[helper_retained_col].width = 18
ws.column_dimensions[helper_not_retained_col].width = 20

r = 4
ws3.cell(row=r, column=1, value="H1 — Retention vs. Discount Rate (Welch's t-test)").font = LABEL_FONT
ws3.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)
r += 1
ws3.cell(row=r, column=1, value="Avg discount — Retained customers").font = NORMAL
ws3.cell(row=r, column=2, value=(
    f"=AVERAGEIF('Raw Data'!{retflag}2:{retflag}{last_row},TRUE,'Raw Data'!{retdisc}2:{retdisc}{last_row})"
)).number_format = "0.00%"
r += 1
ws3.cell(row=r, column=1, value="Avg discount — Not retained customers").font = NORMAL
ws3.cell(row=r, column=2, value=(
    f"=AVERAGEIF('Raw Data'!{retflag}2:{retflag}{last_row},FALSE,'Raw Data'!{retdisc}2:{retdisc}{last_row})"
)).number_format = "0.00%"
r += 1
t1_row = r
ws3.cell(row=r, column=1, value="p-value (two-sample t-test, unequal variance)").font = NORMAL
ws3.cell(row=r, column=2, value=(
    f"=TTEST('Raw Data'!{helper_retained_col}2:{helper_retained_col}{last_row},"
    f"'Raw Data'!{helper_not_retained_col}2:{helper_not_retained_col}{last_row},2,3)"
)).number_format = "0.00000"
r += 1
ws3.cell(row=r, column=1, value="Significant at 0.05?").font = NORMAL
ws3.cell(row=r, column=2, value=f'=IF(B{t1_row}<0.05,"Yes - reject H0","No - fail to reject H0")')

r += 3
ws3.cell(row=r, column=1, value="H2 — Revenue Across Regions (group means; ANOVA run in Python/notebook)").font = LABEL_FONT
ws3.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)
r += 1
region_hdr = r
for j, h in enumerate(["Region", "Avg Revenue", "Order Count"], 1):
    c = ws3.cell(row=r, column=j, value=h)
    c.font = HEADER_FONT
    c.fill = HEADER_FILL
r += 1
for region in sorted(df["Region"].unique()):
    ws3.cell(row=r, column=1, value=region).font = NORMAL
    ws3.cell(row=r, column=2, value=(
        f"=AVERAGEIF('Raw Data'!{region_c}2:{region_c}{last_row},A{r},'Raw Data'!{revenue_c}2:{revenue_c}{last_row})"
    )).number_format = "#,##0.00"
    ws3.cell(row=r, column=3, value=(
        f"=COUNTIF('Raw Data'!{region_c}2:{region_c}{last_row},A{r})"
    ))
    r += 1

r += 2
ws3.cell(row=r, column=1, value="H3 — Discount Rate vs. Profit Margin (Pearson correlation)").font = LABEL_FONT
ws3.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)
r += 1
corr_row = r
ws3.cell(row=r, column=1, value="Correlation coefficient (r)").font = NORMAL
ws3.cell(row=r, column=2, value=(
    f"=CORREL('Raw Data'!{disc_c}2:{disc_c}{last_row},'Raw Data'!{margin_c}2:{margin_c}{last_row})"
)).number_format = "0.000"
r += 1
ws3.cell(row=r, column=1, value="Interpretation").font = NORMAL
ws3.cell(row=r, column=2, value=f'=IF(B{corr_row}<0,"Negative relationship","Positive relationship")')

for col, w in zip("ABCD", [46, 16, 14, 10]):
    ws3.column_dimensions[col].width = w

# ================================================================= KPI Dashboard
ws4 = wb.create_sheet("KPI Dashboard")
ws4["A1"] = "KPI Dashboard — Business Snapshot"
ws4["A1"].font = TITLE_FONT
ws4["A2"] = "All values computed live from Raw Data"
ws4["A2"].font = SUBTITLE_FONT

kpi_defs = [
    ("Total Revenue", f"=SUM('Raw Data'!{revenue_c}2:{revenue_c}{last_row})", "#,##0"),
    ("Total Profit", f"=SUM('Raw Data'!{col_letter['Profit']}2:{col_letter['Profit']}{last_row})", "#,##0"),
    ("Total Orders", f"=COUNTA('Raw Data'!A2:A{last_row})", "#,##0"),
    ("Average Order Value", f"=AVERAGE('Raw Data'!{revenue_c}2:{revenue_c}{last_row})", "#,##0.00"),
    ("Average Discount Rate", f"=AVERAGE('Raw Data'!{disc_c}2:{disc_c}{last_row})", "0.0%"),
    ("Average Profit Margin", f"=AVERAGE('Raw Data'!{margin_c}2:{margin_c}{last_row})", "0.0%"),
    ("Overall Retention Rate", f"=COUNTIF('Raw Data'!{retflag}2:{retflag}{last_row},TRUE)/COUNTA('Raw Data'!{retflag}2:{retflag}{last_row})", "0.0%"),
    ("Avg. Customer Satisfaction (/5)", f"=AVERAGE('Raw Data'!{col_letter['CustomerSatisfaction']}2:{col_letter['CustomerSatisfaction']}{last_row})", "0.00"),
]
r = 4
for label, formula, fmt in kpi_defs:
    ws4.cell(row=r, column=1, value=label).font = LABEL_FONT
    cell = ws4.cell(row=r, column=2, value=formula)
    cell.font = Font(name=FONT, bold=True, size=12, color="1D4ED8")
    cell.number_format = fmt
    cell.fill = ACCENT_FILL
    cell.border = BORDER
    r += 1

r += 2
ws4.cell(row=r, column=1, value="Revenue by Category").font = LABEL_FONT
r += 1
cat_hdr = r
for j, h in enumerate(["Category", "Total Revenue", "% of Total"], 1):
    c = ws4.cell(row=r, column=j, value=h)
    c.font = HEADER_FONT
    c.fill = HEADER_FILL
r += 1
cat_start = r
for cat in sorted(df["Category"].unique()):
    cat_col = col_letter["Category"]
    ws4.cell(row=r, column=1, value=cat).font = NORMAL
    ws4.cell(row=r, column=2, value=(
        f"=SUMIF('Raw Data'!{cat_col}2:{cat_col}{last_row},A{r},'Raw Data'!{revenue_c}2:{revenue_c}{last_row})"
    )).number_format = "#,##0"
    r += 1
cat_end = r - 1
for rr in range(cat_start, cat_end + 1):
    ws4.cell(row=rr, column=3, value=f"=B{rr}/SUM($B${cat_start}:$B${cat_end})").number_format = "0.0%"

for col, w in zip("ABC", [30, 18, 12]):
    ws4.column_dimensions[col].width = w

wb.move_sheet("KPI Dashboard", offset=-3)
wb.save(OUT)
print(f"Workbook saved: {OUT}")
