#!/usr/bin/env python3
"""
run_full_eda.py
============================================================
Standalone, single-command EDA pipeline for Internship Project 04.

Usage:
    python run_full_eda.py

Runs, in order:
    1. generate_data.py   -> data/business_transactions.csv
    2. eda_analysis.py    -> charts/*.png, reports/findings.json,
                              reports/summary_statistics.csv
    3. build_workbook.py  -> reports/EDA_Statistical_Insights.xlsx
    4. build_notebook.py  -> notebooks/EDA_Statistical_Insights.ipynb

Re-run any time the dataset changes to regenerate every deliverable
from a single source of truth.
============================================================
"""

import runpy
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
STEPS = ["generate_data.py", "eda_analysis.py", "build_workbook.py", "build_notebook.py"]


def main():
    for step in STEPS:
        print(f"\n{'='*60}\nRunning {step}\n{'='*60}")
        runpy.run_path(str(SCRIPT_DIR / step), run_name="__main__")
    print("\nAll deliverables generated:")
    print("  data/business_transactions.csv")
    print("  charts/*.png (8 figures)")
    print("  reports/summary_statistics.csv")
    print("  reports/findings.json")
    print("  reports/EDA_Statistical_Insights.xlsx")
    print("  notebooks/EDA_Statistical_Insights.ipynb")


if __name__ == "__main__":
    sys.exit(main())
