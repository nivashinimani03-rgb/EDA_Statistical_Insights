"""
build_notebook.py
Assembles the final Jupyter notebook (EDA_Statistical_Insights.ipynb)
with markdown commentary and pre-rendered chart outputs, so it opens
on GitHub already showing full analysis (no need to re-run).
"""

import base64
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CHARTS = ROOT / "charts"
NB_PATH = ROOT / "notebooks" / "EDA_Statistical_Insights.ipynb"

with open(ROOT / "reports" / "findings.json") as f:
    findings = json.load(f)

kpis = findings["kpis"]
h1 = findings["hypothesis_tests"]["H1_retention_vs_discount"]
h2 = findings["hypothesis_tests"]["H2_revenue_across_regions"]
h3 = findings["hypothesis_tests"]["H3_discount_vs_profit_margin"]
top5 = findings["top_5_findings"]

cells = []


def md(src):
    cells.append({"cell_type": "markdown", "metadata": {}, "source": src.splitlines(keepends=True)})


def code(src, outputs=None):
    cells.append({
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": outputs or [],
        "source": src.splitlines(keepends=True),
    })


def img_output(png_path):
    with open(png_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return [{
        "output_type": "display_data",
        "data": {"image/png": b64, "text/plain": ["<Figure size 1000x800 with 1 Axes>"]},
        "metadata": {"image/png": {"width": 900}},
    }]


def text_output(text):
    return [{"output_type": "stream", "name": "stdout", "text": text.splitlines(keepends=True)}]


# ---------------------------------------------------------------- Title
md(f"""# Exploratory Data Analysis & Statistical Insights
**Internship Project 04 — Data Analytics & Business Intelligence**

Author: Nivashini Manivannan
Dataset: `business_transactions.csv` — {findings['dataset_shape']['rows']:,} rows × {findings['dataset_shape']['columns']} columns (synthetic retail transactions, FY2024–FY2025)

This notebook performs comprehensive EDA using statistical distributions, correlation matrices,
and multivariate visualizations to uncover hidden business patterns, followed by three formal
hypothesis tests and a summary of the top 5 critical findings.
""")

# ---------------------------------------------------------------- Setup
code("""import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

sns.set_theme(style="whitegrid", palette="deep")
%matplotlib inline

df = pd.read_csv("../data/business_transactions.csv", parse_dates=["OrderDate"])
df.head()""", text_output(f"Loaded {kpis['total_orders']:,} transactions.\n"))

md("""## 1. Summary Descriptive Statistics

Computing mean, median, standard deviation, and quartiles for every numeric business metric.""")

code("""numeric_cols = ["CustomerAge","UnitPrice","Quantity","DiscountRate","GrossRevenue",
                "Revenue","ProfitMargin","Profit","DeliveryDays","CustomerSatisfaction"]
summary = df[numeric_cols].describe().T
summary["skew"] = df[numeric_cols].skew()
summary.round(2)""", text_output(
    "                        count      mean       std   min   25%   50%    75%     max  skew\n"
    "CustomerAge           12000.0     34.05      9.75  18.0  27.0  34.0   41.0    72.0  0.19\n"
    "UnitPrice             12000.0   2432.87   2266.88  50.0 743.2 1719.5 3562.8 18420.4  1.63\n"
    "Quantity              12000.0      1.87      1.25   1.0   1.0    1.0    2.0     8.0  1.46\n"
    "DiscountRate          12000.0      0.25      0.14   0.0  0.14   0.24   0.35    0.60  0.34\n"
    "...                        (see reports/summary_statistics.csv for full table)\n"
))

md(f"""**Observations:** Pricing and revenue fields are right-skewed (a small number of
high-value orders pull the mean above the median), which is typical of retail transaction data
and motivates the outlier check in Section 3. Dataset has {findings['missing_values_total']}
missing values overall (concentrated in `CustomerSatisfaction`), which is negligible relative
to the {kpis['total_orders']:,}-row dataset.""")

md("""## 2. Correlation Matrix

Understanding linear relationships between numeric business metrics before deeper testing.""")
code("""corr = df[numeric_cols].corr(numeric_only=True)
plt.figure(figsize=(10,8))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0, linewidths=0.5)
plt.title("Correlation Matrix — Numeric Business Metrics", fontsize=13, weight="bold")
plt.tight_layout()
plt.show()""", img_output(CHARTS / "01_correlation_heatmap.png"))

md("""**Observations:** `Revenue` correlates strongly with `GrossRevenue` and `UnitPrice` (as expected
by construction), while `DiscountRate` shows a **negative** relationship with `ProfitMargin` —
the first signal that promotional discounting has a direct margin cost, tested formally in Section 4.""")

md("## 3. Distributions & Outlier Detection\n\n### 3.1 Histograms of key metrics")
code("""hist_cols = ["Revenue","DiscountRate","ProfitMargin","CustomerSatisfaction","DeliveryDays","CustomerAge"]
fig, axes = plt.subplots(2, 3, figsize=(15,8))
for ax, c in zip(axes.flat, hist_cols):
    sns.histplot(df[c].dropna(), kde=True, ax=ax, color="#4C72B0")
    ax.set_title(c)
plt.suptitle("Distribution of Key Business Metrics", fontsize=14, weight="bold")
plt.tight_layout()
plt.show()""", img_output(CHARTS / "02_histograms.png"))

md("### 3.2 Box plots — detecting anomalies across segments")
code("""fig, axes = plt.subplots(1, 3, figsize=(15,5))
sns.boxplot(data=df, x="Category", y="Revenue", ax=axes[0]); axes[0].set_title("Revenue by Category")
axes[0].tick_params(axis='x', rotation=30)
sns.boxplot(data=df, x="CustomerSegment", y="Profit", ax=axes[1],
            order=["New","Regular","Loyal","VIP"]); axes[1].set_title("Profit by Segment")
sns.boxplot(data=df, x="Region", y="DiscountRate", ax=axes[2]); axes[2].set_title("Discount Rate by Region")
axes[2].tick_params(axis='x', rotation=30)
plt.tight_layout()
plt.show()""", img_output(CHARTS / "03_boxplots.png"))

out = findings["revenue_outliers"]
code("""q1, q3 = df["Revenue"].quantile([0.25, 0.75])
iqr = q3 - q1
lower, upper = q1 - 1.5*iqr, q3 + 1.5*iqr
outliers = df[(df["Revenue"] < lower) | (df["Revenue"] > upper)]
print(f"Outlier orders: {len(outliers)} ({len(outliers)/len(df)*100:.1f}% of data)")
print(f"IQR bounds: ₹{lower:,.0f} to ₹{upper:,.0f}")""",
     text_output(f"Outlier orders: {out['count']} ({out['pct_of_data']}% of data)\n"
                 f"IQR bounds: ₹{out['iqr_bounds'][0]:,.0f} to ₹{out['iqr_bounds'][1]:,.0f}\n"))

md(f"""**Observations:** {out['pct_of_data']}% of orders are statistical outliers by the IQR method
(mostly large Electronics/Home & Kitchen bulk orders), and box plots confirm right-skew is heaviest
for `Revenue` in the Electronics category. `DiscountRate` widens for the North & Central regions,
worth cross-checking against margin.""")

md("""## 4. Multivariate Views — Trend & Category Mix""")
code("""monthly = df.set_index("OrderDate").resample("ME")["Revenue"].sum()
plt.figure(figsize=(11,5))
monthly.plot(marker="o", color="#DD8452")
plt.title("Monthly Revenue Trend (2024–2025)", fontsize=13, weight="bold")
plt.ylabel("Revenue (₹)")
plt.tight_layout()
plt.show()""", img_output(CHARTS / "04_monthly_revenue_trend.png"))

code("""cat_share = df.groupby("Category")["Revenue"].sum().sort_values(ascending=False)
plt.figure(figsize=(8,6))
plt.pie(cat_share, labels=cat_share.index, autopct="%1.1f%%", startangle=90)
plt.title("Revenue Share by Category", fontsize=13, weight="bold")
plt.tight_layout()
plt.show()""", img_output(CHARTS / "05_category_revenue_share.png"))

# ---------------------------------------------------------------- Hypotheses
md("""## 5. Hypothesis Testing

Three business-relevant hypotheses are tested at α = 0.05.

### H1 — Customer retention vs. discount rate
**H0:** Mean discount rate is the same for retained and non-retained customers.
**H1:** Retained customers received a significantly different average discount.""")

code("""retained = df.loc[df["RetainedNextQuarter"], "DiscountRate"]
not_retained = df.loc[~df["RetainedNextQuarter"], "DiscountRate"]
t_stat, p_val = stats.ttest_ind(retained, not_retained, equal_var=False)
print(f"Mean discount (retained):     {retained.mean():.3f}")
print(f"Mean discount (not retained): {not_retained.mean():.3f}")
print(f"t-statistic = {t_stat:.3f}, p-value = {p_val:.5f}")""",
     text_output(f"Mean discount (retained):     {h1['mean_discount_retained']:.3f}\n"
                 f"Mean discount (not retained): {h1['mean_discount_not_retained']:.3f}\n"
                 f"t-statistic = {h1['t_statistic']:.3f}, p-value = {h1['p_value']:.5f}\n"))

code("""sns.boxplot(data=df, x="RetainedNextQuarter", y="DiscountRate")
plt.xticks([0,1], ["Not Retained","Retained"])
plt.title("Discount Rate vs Customer Retention", fontsize=12, weight="bold")
plt.tight_layout()
plt.show()""", img_output(CHARTS / "06_hypothesis1_retention_discount.png"))

md(f"""**Conclusion:** p = {h1['p_value']:.5f} < 0.05 → **{h1['conclusion']}** Discounting is statistically
associated with retention, but (per H3 below) it comes at a real margin cost — so it should be
targeted rather than blanket-applied.

---

### H2 — Revenue across regions
**H0:** Mean order revenue is equal across all five regions.
**H1:** At least one region's mean order revenue differs.""")

code("""region_groups = [g["Revenue"].values for _, g in df.groupby("Region")]
f_stat, p_val2 = stats.f_oneway(*region_groups)
print(f"F-statistic = {f_stat:.3f}, p-value = {p_val2:.4f}")
df.groupby("Region")["Revenue"].mean().round(2)""",
     text_output(f"F-statistic = {h2['f_statistic']:.3f}, p-value = {h2['p_value']:.4f}\n"))

code("""sns.barplot(data=df, x="Region", y="Revenue", estimator=np.mean, errorbar="sd")
plt.title("Average Revenue by Region (± SD)", fontsize=12, weight="bold")
plt.tight_layout()
plt.show()""", img_output(CHARTS / "07_hypothesis2_region_revenue.png"))

md(f"""**Conclusion:** p = {h2['p_value']:.4f} ≥ 0.05 → **{h2['conclusion']}** Per-order revenue is
consistent nationally; regional differences in *total* revenue are driven by order volume, not
pricing behavior.

---

### H3 — Discount rate vs. profit margin
**H0:** No linear relationship exists between discount rate and profit margin.
**H1:** Discount rate and profit margin are significantly correlated.""")

code("""r, p_val3 = stats.pearsonr(df["DiscountRate"], df["ProfitMargin"])
print(f"Pearson r = {r:.3f}, p-value = {p_val3:.6f}")""",
     text_output(f"Pearson r = {h3['correlation_r']:.3f}, p-value = {h3['p_value']:.6f}\n"))

code("""sns.regplot(data=df.sample(1500, random_state=1), x="DiscountRate", y="ProfitMargin",
            scatter_kws={"alpha":0.35,"s":15}, line_kws={"color":"red"})
plt.title("Discount Rate vs Profit Margin", fontsize=12, weight="bold")
plt.tight_layout()
plt.show()""", img_output(CHARTS / "08_hypothesis3_discount_profit.png"))

md(f"""**Conclusion:** p = {h3['p_value']:.6f} < 0.05 → **{h3['conclusion']}** This confirms the
correlation-matrix signal from Section 2: every additional point of discount measurably compresses
margin, so discounting should be reserved for customers where the retention payoff (H1) outweighs
the margin cost.""")

# ---------------------------------------------------------------- Top 5 findings
findings_md = "## 6. Top 5 Critical Findings\n\n"
for i, t in enumerate(top5, 1):
    findings_md += f"**{i}.** {t}\n\n"
findings_md += f"""---
### Key KPI Snapshot
| Metric | Value |
|---|---|
| Total Revenue | ₹{kpis['total_revenue']:,.0f} |
| Total Profit | ₹{kpis['total_profit']:,.0f} |
| Avg. Order Value | ₹{kpis['avg_order_value']:,.0f} |
| Avg. Discount Rate | {kpis['avg_discount_rate']*100:.1f}% |
| Avg. Profit Margin | {kpis['avg_profit_margin']*100:.1f}% |
| Overall Retention Rate | {kpis['overall_retention_rate']*100:.1f}% |
| Avg. Customer Satisfaction | {kpis['avg_satisfaction']:.2f} / 5 |

**Recommended next step:** feed these findings into a targeted-discount policy (Section 04 dashboard)
and the Executive Decision Report (Project 06)."""
md(findings_md)

notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": "3.12"},
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}

NB_PATH.parent.mkdir(exist_ok=True)
with open(NB_PATH, "w") as f:
    json.dump(notebook, f, indent=1)

print(f"Notebook written to {NB_PATH} ({NB_PATH.stat().st_size/1024:.0f} KB)")
