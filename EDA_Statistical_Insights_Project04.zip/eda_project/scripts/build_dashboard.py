"""
build_dashboard.py
Injects findings.json data into the dashboard HTML template so the
dashboard ships as a single, self-contained, static file (no server
or Python needed to view it — works directly on GitHub Pages or
opened locally in a browser).
"""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

with open(ROOT / "reports" / "findings.json") as f:
    findings = json.load(f)

TEMPLATE = (ROOT / "dashboard" / "index_template.html").read_text()
OUT = ROOT / "dashboard" / "index.html"

payload = json.dumps(findings)
html = TEMPLATE.replace("__FINDINGS_JSON__", payload)
OUT.write_text(html)
print(f"Dashboard written: {OUT} ({OUT.stat().st_size/1024:.0f} KB)")
