"""
eda_analysis.py
============================================================
Exploratory Data Analysis & Statistical Insights
Internship Project 04 - Data Analytics & Business Intelligence

Performs:
  1. Summary descriptive statistics
  2. Correlation heatmap, histograms, box plots (anomaly detection)
  3. Three business hypothesis tests
  4. Exports all charts + a JSON of key findings used by the
     dashboard, Excel workbook, and notebook.
============================================================
"""

import json
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "business_transactions.csv"
CHARTS = ROOT / "charts"
CHARTS.mkdir(exist_ok=True)

sns.set_theme(style="whitegrid", palette="deep")
plt.rcParams["figure.dpi"] = 110

# ------------------------------------------------------------------
# Load data
# ------------------------------------------------------------------
df = pd.read_csv(DATA, parse_dates=["OrderDate"])

numeric_cols = [
    "CustomerAge", "UnitPrice", "Quantity", "DiscountRate", "GrossRevenue",
    "Revenue", "ProfitMargin", "Profit", "DeliveryDays", "CustomerSatisfaction",
]

findings = {}

# ------------------------------------------------------------------
# 1. Summary descriptive statistics
# ------------------------------------------------------------------
summary_stats = df[numeric_cols].describe().T
summary_stats["skew"] = df[numeric_cols].skew()
summary_stats["missing"] = df[numeric_cols].isna().sum()
summary_stats.to_csv(ROOT / "reports" / "summary_statistics.csv")

findings["dataset_shape"] = {"rows": int(df.shape[0]), "columns": int(df.shape[1])}
findings["missing_values_total"] = int(df.isna().sum().sum())
findings["summary_stats"] = json.loads(summary_stats.round(3).to_json(orient="index"))

# ------------------------------------------------------------------
# 2a. Correlation heatmap
# ------------------------------------------------------------------
corr = df[numeric_cols].corr(numeric_only=True)
plt.figure(figsize=(10, 8))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0,
            linewidths=0.5, cbar_kws={"label": "Correlation"})
plt.title("Correlation Matrix — Numeric Business Metrics", fontsize=13, weight="bold")
plt.tight_layout()
plt.savefig(CHARTS / "01_correlation_heatmap.png")
plt.close()

findings["top_correlations"] = (
    corr.where(~np.eye(len(corr), dtype=bool))
    .unstack()
    .drop_duplicates()
    .abs()
    .sort_values(ascending=False)
    .head(6)
    .index.tolist()
)

# ------------------------------------------------------------------
# 2b. Histograms of key distributions
# ------------------------------------------------------------------
hist_cols = ["Revenue", "DiscountRate", "ProfitMargin", "CustomerSatisfaction",
             "DeliveryDays", "CustomerAge"]
fig, axes = plt.subplots(2, 3, figsize=(15, 8))
for ax, col in zip(axes.flat, hist_cols):
    sns.histplot(df[col].dropna(), kde=True, ax=ax, color="#4C72B0")
    ax.set_title(col)
plt.suptitle("Distribution of Key Business Metrics", fontsize=14, weight="bold")
plt.tight_layout()
plt.savefig(CHARTS / "02_histograms.png")
plt.close()

# ------------------------------------------------------------------
# 2c. Box plots to detect anomalies/outliers
# ------------------------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
sns.boxplot(data=df, x="Category", y="Revenue", ax=axes[0])
axes[0].set_title("Revenue by Category (outlier check)")
axes[0].tick_params(axis="x", rotation=30)

sns.boxplot(data=df, x="CustomerSegment", y="Profit", ax=axes[1],
            order=["New", "Regular", "Loyal", "VIP"])
axes[1].set_title("Profit by Customer Segment")

sns.boxplot(data=df, x="Region", y="DiscountRate", ax=axes[2])
axes[2].set_title("Discount Rate by Region")
axes[2].tick_params(axis="x", rotation=30)

plt.tight_layout()
plt.savefig(CHARTS / "03_boxplots.png")
plt.close()

# outlier detection via IQR on Revenue
q1, q3 = df["Revenue"].quantile([0.25, 0.75])
iqr = q3 - q1
lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
outliers = df[(df["Revenue"] < lower) | (df["Revenue"] > upper)]
findings["revenue_outliers"] = {
    "count": int(len(outliers)),
    "pct_of_data": round(len(outliers) / len(df) * 100, 2),
    "iqr_bounds": [round(lower, 2), round(upper, 2)],
}

# ------------------------------------------------------------------
# Extra visual: Revenue trend + category mix (useful for dashboard)
# ------------------------------------------------------------------
monthly = df.set_index("OrderDate").resample("ME")["Revenue"].sum()
plt.figure(figsize=(11, 5))
monthly.plot(marker="o", color="#DD8452")
plt.title("Monthly Revenue Trend (2024–2025)", fontsize=13, weight="bold")
plt.ylabel("Revenue (₹)")
plt.tight_layout()
plt.savefig(CHARTS / "04_monthly_revenue_trend.png")
plt.close()

plt.figure(figsize=(8, 6))
cat_share = df.groupby("Category")["Revenue"].sum().sort_values(ascending=False)
plt.pie(cat_share, labels=cat_share.index, autopct="%1.1f%%", startangle=90,
        colors=sns.color_palette("deep"))
plt.title("Revenue Share by Category", fontsize=13, weight="bold")
plt.tight_layout()
plt.savefig(CHARTS / "05_category_revenue_share.png")
plt.close()

# ------------------------------------------------------------------
# 3. Hypothesis tests
# ------------------------------------------------------------------
hyp_results = {}

# H1: Customer retention vs discount rate
# t-test comparing mean discount rate between retained vs not-retained customers
retained = df.loc[df["RetainedNextQuarter"], "DiscountRate"]
not_retained = df.loc[~df["RetainedNextQuarter"], "DiscountRate"]
t_stat, p_val = stats.ttest_ind(retained, not_retained, equal_var=False)
hyp_results["H1_retention_vs_discount"] = {
    "hypothesis": "Customers who received higher discounts are more likely to be retained next quarter.",
    "test": "Welch's t-test (independent samples)",
    "mean_discount_retained": round(retained.mean(), 4),
    "mean_discount_not_retained": round(not_retained.mean(), 4),
    "t_statistic": round(float(t_stat), 3),
    "p_value": float(p_val),
    "significant_at_0.05": bool(p_val < 0.05),
    "conclusion": (
        "Reject H0: retained customers received significantly higher average discounts."
        if p_val < 0.05 else
        "Fail to reject H0: no significant difference in discount rate between groups."
    ),
}

plt.figure(figsize=(7, 5))
sns.boxplot(data=df, x="RetainedNextQuarter", y="DiscountRate")
plt.xticks([0, 1], ["Not Retained", "Retained"])
plt.title("Discount Rate vs Customer Retention", fontsize=12, weight="bold")
plt.tight_layout()
plt.savefig(CHARTS / "06_hypothesis1_retention_discount.png")
plt.close()

# H2: Revenue differs across regions (one-way ANOVA)
region_groups = [g["Revenue"].values for _, g in df.groupby("Region")]
f_stat, p_val2 = stats.f_oneway(*region_groups)
hyp_results["H2_revenue_across_regions"] = {
    "hypothesis": "Average order revenue differs significantly across regions.",
    "test": "One-way ANOVA",
    "f_statistic": round(float(f_stat), 3),
    "p_value": float(p_val2),
    "significant_at_0.05": bool(p_val2 < 0.05),
    "region_means": df.groupby("Region")["Revenue"].mean().round(2).to_dict(),
    "conclusion": (
        "Reject H0: at least one region has significantly different average revenue."
        if p_val2 < 0.05 else
        "Fail to reject H0: revenue does not differ significantly by region."
    ),
}

plt.figure(figsize=(7, 5))
sns.barplot(data=df, x="Region", y="Revenue", estimator=np.mean, errorbar="sd")
plt.title("Average Revenue by Region (± SD)", fontsize=12, weight="bold")
plt.tight_layout()
plt.savefig(CHARTS / "07_hypothesis2_region_revenue.png")
plt.close()

# H3: Discount rate and profit margin are negatively correlated
r, p_val3 = stats.pearsonr(df["DiscountRate"], df["ProfitMargin"])
hyp_results["H3_discount_vs_profit_margin"] = {
    "hypothesis": "Higher discount rates are associated with lower profit margins.",
    "test": "Pearson correlation",
    "correlation_r": round(float(r), 3),
    "p_value": float(p_val3),
    "significant_at_0.05": bool(p_val3 < 0.05),
    "conclusion": (
        f"Reject H0: significant {'negative' if r < 0 else 'positive'} correlation "
        f"(r={r:.2f}) found between discount rate and profit margin."
        if p_val3 < 0.05 else
        "Fail to reject H0: no significant linear relationship found."
    ),
}

plt.figure(figsize=(7, 5))
sns.regplot(data=df.sample(1500, random_state=1), x="DiscountRate", y="ProfitMargin",
            scatter_kws={"alpha": 0.35, "s": 15}, line_kws={"color": "red"})
plt.title("Discount Rate vs Profit Margin", fontsize=12, weight="bold")
plt.tight_layout()
plt.savefig(CHARTS / "08_hypothesis3_discount_profit.png")
plt.close()

findings["hypothesis_tests"] = hyp_results

# ------------------------------------------------------------------
# KPI snapshot for dashboard/Excel
# ------------------------------------------------------------------
kpis = {
    "total_revenue": round(df["Revenue"].sum(), 2),
    "total_profit": round(df["Profit"].sum(), 2),
    "avg_order_value": round(df["Revenue"].mean(), 2),
    "avg_discount_rate": round(df["DiscountRate"].mean(), 4),
    "avg_profit_margin": round(df["ProfitMargin"].mean(), 4),
    "overall_retention_rate": round(df["RetainedNextQuarter"].mean(), 4),
    "avg_satisfaction": round(df["CustomerSatisfaction"].mean(), 2),
    "total_orders": int(len(df)),
}
findings["kpis"] = kpis

findings["by_region_revenue"] = df.groupby("Region")["Revenue"].sum().round(2).to_dict()
findings["by_category_revenue"] = df.groupby("Category")["Revenue"].sum().round(2).to_dict()
findings["by_segment_retention"] = df.groupby("CustomerSegment")["RetainedNextQuarter"].mean().round(4).to_dict()
findings["monthly_revenue"] = {k.strftime("%Y-%m"): round(v, 2) for k, v in monthly.items()}

# ------------------------------------------------------------------
# 4. Top 5 critical findings (markdown-ready)
# ------------------------------------------------------------------
top5 = [
    (
        "Discounting drives short-term retention but erodes margin — "
        f"retained customers received a {retained.mean()*100:.1f}% average discount vs "
        f"{not_retained.mean()*100:.1f}% for non-retained (p={hyp_results['H1_retention_vs_discount']['p_value']:.4f}), "
        f"while discount rate and profit margin are negatively correlated (r={r:.2f})."
    ),
    (
        f"{kpis['overall_retention_rate']*100:.1f}% of customers are projected to be retained next quarter, "
        f"with VIP segment retention at {findings['by_segment_retention'].get('VIP', 0)*100:.1f}% vs "
        f"New customers at {findings['by_segment_retention'].get('New', 0)*100:.1f}% — loyalty segment is the "
        "strongest retention lever."
    ),
    (
        f"Average order revenue does not differ significantly by region (ANOVA p={hyp_results['H2_revenue_across_regions']['p_value']:.4f}), "
        "indicating consistent per-order performance nationally — though total revenue still varies by region "
        f"since {max(findings['by_region_revenue'], key=findings['by_region_revenue'].get)} generates the most volume "
        f"(₹{max(findings['by_region_revenue'].values()):,.0f})."
    ),
    (
        f"{list(cat_share.index)[0]} and {list(cat_share.index)[1]} together generate "
        f"{(cat_share.iloc[0] + cat_share.iloc[1]) / cat_share.sum() * 100:.1f}% of total revenue, "
        "making category mix a key driver of top-line performance."
    ),
    (
        f"Revenue has {findings['revenue_outliers']['pct_of_data']:.1f}% high-value outlier orders "
        f"(above ₹{findings['revenue_outliers']['iqr_bounds'][1]:,.0f} via IQR method) that disproportionately "
        "influence average order value and should be monitored separately from typical transactions."
    ),
]
findings["top_5_findings"] = top5

with open(ROOT / "reports" / "findings.json", "w") as f:
    json.dump(findings, f, indent=2, default=str)

print("EDA complete.")
print(f"Charts saved to: {CHARTS}")
print(f"Findings saved to: {ROOT / 'reports' / 'findings.json'}")
for i, t in enumerate(top5, 1):
    print(f"\n{i}. {t}")
